
# Web Application + IIS + MSBuild (DevPod)

## Como usar

1. Adicionar o provider:
   ```powershell
devpod provider add .\windows-docker-provider.yaml
   ```

2. Subir workspace com VSCode:
   ```powershell
devpod up . --provider windows-docker --ide vscode
   ```

3. Acessar no browser:
   - http://localhost:8080

4. Debug:
   - Run → Attach IIS (w3wp)
