
# Dev SDK + IIS + (Opcional) HTTPS — DevPod

## Requisitos
- Windows 10/11 Pro/Enterprise ou Windows Server (Docker em modo **Windows Containers**)
- DevPod instalado

## Uso
1) Adicionar Provider
```powershell
devpod provider add .\windows-docker-provider.yaml
```

2) Subir workspace
```powershell
devpod up . --provider windows-docker --ide vscode
```

3) Acessar
- HTTP:  http://localhost:8080
- HTTPS: https://localhost:8443  (se você fornecer PFX + senha)

## Habilitar HTTPS
- Coloque seu PFX em `certs/site.pfx`
- Defina a senha como variável de ambiente quando for criar o container (DevPod Desktop → Environment) ou via CLI com provider custom
- A variável esperada é: `HTTPS_PFX_PASSWORD`

## Recompilar sem reiniciar DevPod
Abra o terminal do container e execute:
```powershell
msbuild C:pp\WebApp.csproj /p:Configuration=Debug
Copy-Item C:pp\* C:\inetpub\wwwroot -Recurse -Force
```

## Depurar
Use a configuração `.vscode/launch.json` → **Attach IIS (w3wp)**.
