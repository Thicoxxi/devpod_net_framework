
using System;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lbl.Text = "Hot build + optional HTTPS in container: " + DateTime.Now.ToString("u");
    }
}
