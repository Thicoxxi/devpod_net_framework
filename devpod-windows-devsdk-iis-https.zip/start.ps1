# Build the web application
msbuild C:\app\WebApp.csproj /p:Configuration=Debug

# Deploy to IIS root
Copy-Item C:\app\* C:\inetpub\wwwroot -Recurse -Force

# Optional: clean obj/ bin/ in site root if copied
Remove-Item C:\inetpub\wwwroot\obj -Recurse -Force -ErrorAction SilentlyContinue

# HTTPS binding with PFX (if present)
$passwordPlain = $env:HTTPS_PFX_PASSWORD
if (Test-Path C:\certs\site.pfx -and -not [string]::IsNullOrEmpty($passwordPlain)) {
  try {
    $sec = ConvertTo-SecureString $passwordPlain -AsPlainText -Force
    $cert = Import-PfxCertificate -FilePath C:\certs\site.pfx -Password $sec -CertStoreLocation Cert:\LocalMachine\My
    $thumb = $cert.Thumbprint

    Import-Module WebAdministration
    # Ensure HTTPS binding exists
    if (-not (Get-WebBinding -Name "Default Web Site" -Protocol https -ErrorAction SilentlyContinue)) {
      New-WebBinding -Name "Default Web Site" -Protocol https -Port 443 -IPAddress "*"
    }
    Set-Location IIS:\SslBindings
    Get-Item "0.0.0.0!443" | Set-Item -Thumbprint $thumb -StoreName My
  } catch {
    Write-Host "[WARN] Failed to import/bind certificate: $($_.Exception.Message)"
  }
} else {
  Write-Host "[INFO] No PFX or password provided. HTTPS binding will not be configured."
}

# Start IIS
& C:\ServiceMonitor.exe w3svc
