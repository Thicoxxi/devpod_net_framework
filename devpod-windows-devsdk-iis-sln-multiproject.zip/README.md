
# Dev SDK + IIS + Solution (.sln) com 2 projetos (.csproj)

Este exemplo contém:
- **WebFormsApp** (WebForms .NET Framework 4.8)
- **BasicApi** (API básica usando System.Web.Http no IIS)
- **Solution.sln** referenciando os dois projetos
- **IIS + SDK (MSBuild)** no mesmo container → você recompila SEM reiniciar o DevPod

## Como usar
1. Provider DevPod:
   ```powershell
   devpod provider add .\windows-docker-provider.yaml
   ```
2. Subir o workspace com VSCode:
   ```powershell
   devpod up . --provider windows-docker --ide vscode
   ```
3. Acessar no navegador:
   - WebForms: http://localhost:8080/Default.aspx
   - API:      http://localhost:8080/api/hello
4. Recompilar sem reiniciar (terminal do container):
   ```powershell
   msbuild C:\src\Solution.sln /p:Configuration=Debug
   Copy-Item C:\src\WebFormsApp\* C:\inetpub\wwwroot -Recurse -Force
   Copy-Item C:\src\BasicApi\* C:\inetpub\wwwroot -Recurse -Force
   ```
5. Debug: VSCode → Run → **Attach IIS (w3wp)**.

> Observação: este exemplo mantém tudo simples (cópia direta para `wwwroot`). Em produção, separe pastas virtuais/aplicativos no IIS e copie apenas artefatos de build.
