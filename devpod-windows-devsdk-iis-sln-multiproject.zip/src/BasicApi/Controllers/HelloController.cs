
using System;
using System.Web.Http;

namespace BasicApi.Controllers
{
    public class HelloController : ApiController
    {
        [HttpGet]
        public IHttpActionResult Get()
        {
            return Ok(new { message = "Hello from BasicApi", time = DateTime.UtcNow });
        }
    }
}
