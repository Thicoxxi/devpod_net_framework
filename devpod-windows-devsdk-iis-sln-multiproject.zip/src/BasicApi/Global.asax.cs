
using System;
using System.Web;

namespace BasicApi
{
    public class WebApiApplication : HttpApplication
    {
        protected void Application_Start()
        {
            App_Start.WebApiConfig.Register(System.Web.Http.GlobalConfiguration.Configuration);
        }
    }
}
