
using System;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lbl.Text = "WebForms rodando. " + DateTime.Now.ToString("u");
    }
}
