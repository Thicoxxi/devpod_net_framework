
# Build solution (Debug)
msbuild C:\src\Solution.sln /p:Configuration=Debug

# Deploy: copy WebFormsApp and BasicApi to IIS root
# For simplicity, copy everything; in real world, copy bin and views/static selectively
Copy-Item C:\src\WebFormsApp\* C:\inetpub\wwwroot -Recurse -Force
# Create application for API under /api if desired, but simplest is to copy alongside and rely on route
Copy-Item C:\src\BasicApi\* C:\inetpub\wwwroot -Recurse -Force

# Ensure Default Document for WebForms
Import-Module WebAdministration
if (-not (Get-WebConfigurationProperty -pspath IIS:\ -filter system.webServer/defaultDocument/files -name "." | where {$_.value -like "*Default.aspx*"})) {
    Add-WebConfigurationProperty -pspath IIS:\ -filter system.webServer/defaultDocument/files -name "." -value @{value="Default.aspx"}
}

# Start IIS
& C:\ServiceMonitor.exe w3svc
