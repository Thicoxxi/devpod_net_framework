
using System;
public partial class _Default : System.Web.UI.Page{protected void Page_Load(object s,EventArgs e){lbl.Text="Hot build inside container: "+DateTime.Now.ToString("u");}}
