
# Windows Container + IIS + HTTPS Example (DevPod)

## Passos:
1. Coloque o arquivo `.pfx` dentro da pasta `certs/` com nome `site.pfx`.
2. Ajuste a senha no arquivo `start.ps1`.
3. Adicione provider:
   ```powershell
   devpod provider add .\windows-docker-provider.yaml
   ```
4. Suba o workspace:
   ```powershell
   devpod up . --provider windows-docker --ide vscode
   ```
5. Acesse:
   - HTTP: http://localhost:8080
   - HTTPS: https://localhost:8443

## Observação
Certificados devem ser manipulados com cuidado. Não versione .pfx no Git.
