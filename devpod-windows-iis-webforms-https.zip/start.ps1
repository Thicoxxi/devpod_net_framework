# Import certificate
$password = ConvertTo-SecureString "PASSWORD_HERE" -AsPlainText -Force
$cert = Import-PfxCertificate -FilePath "C:\certs\site.pfx" -Password $password -CertStoreLocation Cert:\LocalMachine\My
$thumb = $cert.Thumbprint

# Bind HTTPS
iisreset /stop
Import-Module WebAdministration
New-WebBinding -Name "Default Web Site" -Protocol https -Port 443 -IPAddress "*" -ErrorAction SilentlyContinue

Set-Location IIS:\SslBindings
Get-Item "0.0.0.0!443" | Set-Item -Thumbprint $thumb -StoreName My

iisreset /start

# Start IIS in foreground
& C:\ServiceMonitor.exe w3svc
