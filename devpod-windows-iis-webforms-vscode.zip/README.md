
# DevPod + Windows Containers + IIS + WebForms (VSCode Desktop)

Este exemplo usa **VSCode Desktop** (não VSCode Web). O DevPod instalará automaticamente o VS Code Server no container.

## Pré-requisitos
- Docker Desktop em modo **Windows Containers**
- Windows 10/11 Pro/Enterprise
- Hyper-V habilitado
- DevPod instalado

## Como usar
```powershell
devpod provider add .\windows-docker-provider.yaml
devpod up . --provider windows-docker --ide vscode
```

O VSCode abrirá conectado ao container.

## IIS
- http://localhost:8080

## Debug WebForms
- Configuração disponível em `.vscode/launch.json`
- Primeiro abra o site (para iniciar w3wp.exe), depois faça Attach.
