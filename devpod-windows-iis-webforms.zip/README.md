
# DevPod + Windows Containers + IIS + WebForms + OpenVSCode Web (Exemplo)

## Pré-requisitos
- Windows 10/11 Pro/Enterprise (ou Windows Server)
- Docker Desktop instalado
- Docker em modo **Windows Containers** (clique no ícone do Docker → *Switch to Windows Containers…*)
- Hyper-V habilitado
- DevPod instalado (Desktop ou CLI)

## Como usar

1. **Troque para Windows Containers** no Docker Desktop.
2. Abra um terminal na pasta `devpod-windows-iis-webforms`.
3. Adicione o provider:
   ```powershell
   devpod provider add .\windows-docker-provider.yaml
   ```
4. Suba o workspace com VS Code (server) dentro do container:
   ```powershell
   devpod up . --provider windows-docker --ide vscode
   ```
   > O DevPod vai construir a imagem, criar o container, injetar o agente e abrir o VS Code conectado ao container.

5. **Acesse o site no IIS**:
   - http://localhost:8080
   - Pela LAN: http://SEU_PC:8080

6. **Acesse o VSCode Web (OpenVSCode)** dentro do container:
   - http://localhost:3000
   - Pela LAN: http://SEU_PC:3000

7. **Depurar WebForms (IIS)**:
   - No VS Code, use a configuração `Attach IIS (w3wp)` (arquivo `.vscode/launch.json`).
   - Primeiro, acesse o site para iniciar o processo `w3wp.exe`, depois faça *Attach*.

## Estrutura
```
devpod-windows-iis-webforms/
  Dockerfile
  start.ps1
  windows-docker-provider.yaml
  .devcontainer/
    devcontainer.json
  .vscode/
    launch.json
  site/
    Default.aspx
    Default.aspx.cs
    Web.config
```

## Observações
- O `start.ps1` inicia o **OpenVSCode Server** na porta **3000** e mantém o **IIS** em primeiro plano via `ServiceMonitor.exe`.
- Se o OpenVSCode pedir *connection token*, copie do log do container.
- Para mudar portas: altere `appPorts` no `devcontainer.json` e o `--port` no `start.ps1`.
