# Start OpenVSCode Server in background
$ovscode = Start-Process -FilePath "C:\openvscode\bin\openvscode-server.cmd" -ArgumentList "--host 0.0.0.0 --port 3000" -PassThru

# Start IIS via ServiceMonitor in foreground to keep container alive
& C:\ServiceMonitor.exe w3svc
