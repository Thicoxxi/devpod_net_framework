
# .NET Framework 4.x – IIS + VS Code (Attach) – DevPod

Este exemplo permite **depuração pelo IIS** de duas formas:

1. **VS Code (Attach)** – usa a configuração de depuração do próprio VS Code para anexar ao `w3wp.exe` (tipo `clr`).
2. **Visual Studio (Attach / Remote Debugger opcional)** – se preferir o Visual Studio, anexe ao `w3wp.exe` localmente; para cenários remotos, use os **Remote Tools** (msvsmon) adequados à sua versão do VS (instale fora do container).

> Observação: quando você usa **DevPod** com IDE = `vscode`, ele abre o VS Code Desktop já conectado ao **VS Code Server dentro do container**, facilitando o fluxo remoto.

---

## 1) Subir com DevPod (VS Code Remoto)
```powershell
# Dentro desta pasta
devpod provider add .\windows-docker-provider.yaml

devpod up . --provider windows-docker --ide vscode
```
- O DevPod constrói a imagem, cria o container, injeta o VS Code Server e abre o VS Code **conectado ao container**.

## 2) Acessar no navegador
- HTTP: `http://localhost:8080`

## 3) Depurar com o **VS Code** (Attach ao IIS)
1. Acesse a página (para iniciar o `w3wp.exe`).
2. No VS Code → **Run** → selecione **Attach IIS (w3wp)**.
3. Coloque breakpoints (ex.: em `Default.aspx.cs`).

> Se preferir, use a config **Attach por PID (w3wp)** (útil quando há múltiplos pools/processos).

## 4) Recompilar sem reiniciar o DevPod
No terminal do VS Code (dentro do container):
```powershell
msbuild C:\app\WebApp.csproj /p:Configuration=Debug
Copy-Item C:\app\* C:\inetpub\wwwroot -Recurse -Force
```
Ou rode o helper:
```powershell
powershell -File C:\tools\build.ps1
```

## 5) Depurar com **Visual Studio** (opcional)
- Se estiver na **mesma máquina** do IIS/container, use **Debug → Attach to Process…** e selecione `w3wp.exe`.
- Para **depuração remota** (ou quando o VS Code não é opção):
  1. Instale os **Remote Tools** (msvsmon) na máquina/VM Windows **hospedeira** (não dentro do container) na versão do seu Visual Studio.
  2. Inicie o `msvsmon.exe` com as opções recomendadas (autenticação adequada ao seu ambiente).
  3. No Visual Studio → **Debug → Attach to Process…** → use o **Qualifier** mostrado pelo `msvsmon` e anexe ao `w3wp.exe` do app pool correto.

> Dicas: Se houver vários `w3wp.exe`, use **IIS Manager → Worker Processes** ou `appcmd list wp` para mapear **PID ↔ app pool**. Em ambientes mais restritos, você pode precisar executar o VS/VS Code com permissões elevadas para anexar ao `w3wp`.

---

## 6) Onde editar
Edite os arquivos em `app/` (ex.: `Default.aspx`, `Default.aspx.cs`, `WebApp.csproj`).

- O `start.ps1` compila e publica para `C:\inetpub\wwwroot` ao iniciar.
- Para rebuild, use o `tools\build.ps1` ou os comandos acima.

Bom dev! 🚀
