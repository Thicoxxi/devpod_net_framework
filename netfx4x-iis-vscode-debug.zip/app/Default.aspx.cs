
using System;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lbl.Text = "Hello from .NET Framework 4.x (" + DateTime.Now.ToString("u") + ")";
    }
}
