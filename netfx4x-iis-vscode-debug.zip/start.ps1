# Build (Debug) and deploy to IIS root
msbuild C:\app\WebApp.csproj /p:Configuration=Debug
Copy-Item C:\app\* C:\inetpub\wwwroot -Recurse -Force
# ensure default document
Import-Module WebAdministration
if (-not (Get-WebConfigurationProperty -pspath IIS:\ -filter system.webServer/defaultDocument/files -name "." | where {$_.value -like "*Default.aspx*"})) {
    Add-WebConfigurationProperty -pspath IIS:\ -filter system.webServer/defaultDocument/files -name "." -value @{value="Default.aspx"}
}
# run IIS
& C:\ServiceMonitor.exe w3svc
