# Rebuild and refresh IIS content (run inside the container)
param(
  [string]$Configuration = 'Debug'
)
msbuild C:\app\WebApp.csproj /p:Configuration=$Configuration
Copy-Item C:\app\* C:\inetpub\wwwroot -Recurse -Force
Write-Host "Build + copy done. Test at http://localhost:8080" -ForegroundColor Green
