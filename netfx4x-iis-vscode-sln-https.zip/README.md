
# .NET Framework 4.x – Solução (.sln) – VS Code + IIS – HTTPS (PFX) – DevPod

Este pacote adiciona **HTTPS com PFX** ao exemplo `.sln` (WebFormsApp + LibUtil), mantendo:
- **VS Code Attach** ao `w3wp.exe` (tipo `clr`)
- **MSBuild dentro do container** (rebuild sem reiniciar o DevPod)

## Como usar
1) **Coloque o seu certificado** em `certs/site.pfx` (não versione este arquivo).
2) **Defina a senha do PFX** como variável de ambiente do workspace DevPod:
   - `HTTPS_PFX_PASSWORD=SuaSenhaAqui`
3) **Suba o workspace**
   ```powershell
   devpod provider add .\windows-docker-provider.yaml
   devpod up . --provider windows-docker --ide vscode
   ```

## Acessar
- HTTP:  `http://localhost:8080`
- HTTPS: `https://localhost:8443`

## Depurar no VS Code
1. Acesse a página para iniciar o `w3wp`.
2. VS Code → **Run → Attach IIS (w3wp)**.

## Recompilar sem reiniciar
```powershell
msbuild C:\src\Solution.sln /p:Configuration=Debug
Copy-Item C:\src\WebFormsApp\* C:\inetpub\wwwroot -Recurse -Force
```
Ou:
```powershell
powershell -File C:	oolsuild.ps1
```

> Observação: para **Visual Studio**, use **Attach to Process… → w3wp.exe** (remoto com msvsmon na máquina hospedeira, se necessário).
