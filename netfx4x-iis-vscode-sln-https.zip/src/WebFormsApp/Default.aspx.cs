
using System;
using LibUtil;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lbl.Text = $"Hello (.sln HTTPS)! {DateTime.Now:u} — {Msg.GetMessage()}";
    }
}
