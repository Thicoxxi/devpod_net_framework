
# Build solution
msbuild C:\src\Solution.sln /p:Configuration=Debug

# Deploy WebFormsApp to IIS root
Copy-Item C:\src\WebFormsApp\* C:\inetpub\wwwroot -Recurse -Force

# Ensure Default.aspx is default document
Import-Module WebAdministration
if (-not (Get-WebConfigurationProperty -pspath IIS:\ -filter system.webServer/defaultDocument/files -name "." | where {$_.value -like "*Default.aspx*"})) {
    Add-WebConfigurationProperty -pspath IIS:\ -filter system.webServer/defaultDocument/files -name "." -value @{value="Default.aspx"}
}

# Optional HTTPS binding using PFX
$passwordPlain = $env:HTTPS_PFX_PASSWORD
if (Test-Path C:\certs\site.pfx -and -not [string]::IsNullOrEmpty($passwordPlain)) {
  try {
    $sec = ConvertTo-SecureString $passwordPlain -AsPlainText -Force
    $cert = Import-PfxCertificate -FilePath C:\certs\site.pfx -Password $sec -CertStoreLocation Cert:\LocalMachine\My
    $thumb = $cert.Thumbprint

    # Create HTTPS binding if not exists
    if (-not (Get-WebBinding -Name "Default Web Site" -Protocol https -ErrorAction SilentlyContinue)) {
      New-WebBinding -Name "Default Web Site" -Protocol https -Port 443 -IPAddress "*"
    }
    Set-Location IIS:\SslBindings
    Get-Item "0.0.0.0!443" | Set-Item -Thumbprint $thumb -StoreName My
  }
  catch {
    Write-Host "[WARN] Falha ao importar/associar o certificado: $($_.Exception.Message)"
  }
} else {
  Write-Host "[INFO] Sem PFX ou senha — HTTPS não será configurado."
}

# Start IIS
& C:\ServiceMonitor.exe w3svc
