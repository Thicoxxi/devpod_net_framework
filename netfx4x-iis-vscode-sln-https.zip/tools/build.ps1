
param([string]$Configuration='Debug')
msbuild C:\src\Solution.sln /p:Configuration=$Configuration
Copy-Item C:\src\WebFormsApp\* C:\inetpub\wwwroot -Recurse -Force
Write-Host "Solution rebuilt and deployed to IIS. Open http://localhost:8080 or https://localhost:8443" -ForegroundColor Green
