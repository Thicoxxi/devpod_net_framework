
# .NET Framework 4.x – Solução (.sln) – VS Code + IIS – DevPod

Este pacote contém uma **Solution.sln** com 2 projetos:
- **WebFormsApp** (WebForms .NET Framework 4.8)
- **LibUtil** (Class Library .NET Framework 4.8) – referenciada por WebFormsApp

Tudo roda dentro de um **Windows Container** com **SDK 4.8 + IIS**, permitindo:
- **Depurar no VS Code** (Attach ao `w3wp.exe`, tipo `clr`)
- **Recompilar sem reiniciar o DevPod** (MSBuild dentro do container)
- **Visual Studio (opcional)**: Attach ao `w3wp` local ou via Remote Tools na máquina hospedeira

## Como subir (DevPod + VS Code)
```powershell
devpod provider add .\windows-docker-provider.yaml
devpod up . --provider windows-docker --ide vscode
```
- O DevPod abrirá o VS Code Desktop conectado ao VS Code Server dentro do container.

## Acessar
- `http://localhost:8080` (Default.aspx)

## Depurar no VS Code
1. Abra a página (para iniciar o `w3wp`).
2. VS Code → **Run → Attach IIS (w3wp)**.
3. Coloque breakpoints em `Default.aspx.cs`.

## Recompilar sem reiniciar o DevPod
Terminal do container:
```powershell
msbuild C:\src\Solution.sln /p:Configuration=Debug
Copy-Item C:\src\WebFormsApp\* C:\inetpub\wwwroot -Recurse -Force
```
Ou:
```powershell
powershell -File C:	oolsuild.ps1
```

## Visual Studio (opcional)
- Na mesma máquina: **Debug → Attach to Process… → w3wp.exe**
- Remoto: instale **Remote Tools (msvsmon)** na máquina/VM hospedeira e faça o Attach ao `w3wp` conforme o Qualifier do msvsmon.

Bom dev! 🚀
