
using System;

namespace LibUtil
{
    public static class Msg
    {
        public static string GetMessage()
        {
            return "Mensagem da LibUtil: tudo ok!";
        }
    }
}
