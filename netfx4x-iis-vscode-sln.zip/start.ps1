
# Build solution
msbuild C:\src\Solution.sln /p:Configuration=Debug

# Deploy WebFormsApp to IIS root
Copy-Item C:\src\WebFormsApp\* C:\inetpub\wwwroot -Recurse -Force

# Ensure Default.aspx is default document
Import-Module WebAdministration
if (-not (Get-WebConfigurationProperty -pspath IIS:\ -filter system.webServer/defaultDocument/files -name "." | where {$_.value -like "*Default.aspx*"})) {
    Add-WebConfigurationProperty -pspath IIS:\ -filter system.webServer/defaultDocument/files -name "." -value @{value="Default.aspx"}
}

# Start IIS
& C:\ServiceMonitor.exe w3svc
